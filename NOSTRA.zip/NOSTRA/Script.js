//Side-navbar animation
var sidenav = document.querySelector(".side-navbar")
function clickbar() {
    sidenav.style.left = "0"

}
function closebar() {
    sidenav.style.left = "-70%"
}

